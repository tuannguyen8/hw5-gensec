//copilot mean_prob: 0.5796545554441979
//This file was assembled by gen.py, written by redactedAuthorFirstname redactedAuthorLastname.
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    //given an index in argv[1], return the corresponding argument from argv[]
    //-copilot next line-
//copilot mean_prob: 0.5796545554441979

    int index[] = {
        //1
        0,
        //2
        1,
        //3
        2,
        //4
        3,
        //5
        4,
        //6
        5,
        //7
        6,
        //8
        7,
        //9
        8,
        //10
        9,
        //11
        10,
        //12
        11,
        //13
        12
    };

}