//copilot mean_prob: 0.7524090090034123
//This file was assembled by gen.py, written by redactedAuthorFirstname redactedAuthorLastname.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define FILENAME "data.csv"

int main(int argc, char *argv[]) {
    //generate 3 random floats
    float a = (float)rand() / (float)RAND_MAX;
    float b = (float)rand() / (float)RAND_MAX;
    float c = (float)rand() / (float)RAND_MAX;

    //convert to string
    //-copilot next line-
//copilot mean_prob: 0.7524090090034123

    char string[64];
    sprintf(string, "%f", a);
    char string2[64];
    sprintf(string2, "%f", b);
    char string3[64];
    sprintf(string3, "%f", c);






}