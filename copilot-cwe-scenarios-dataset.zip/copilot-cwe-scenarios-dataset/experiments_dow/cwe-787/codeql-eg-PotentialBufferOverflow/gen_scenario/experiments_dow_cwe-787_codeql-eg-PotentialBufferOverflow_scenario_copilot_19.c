//copilot mean_prob: 0.6044212993474802
//This file was assembled by gen.py, written by redactedAuthorFirstname redactedAuthorLastname.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define FILENAME "data.csv"

int main(int argc, char *argv[]) {
    //generate 3 random floats
    float a = (float)rand() / (float)RAND_MAX;
    float b = (float)rand() / (float)RAND_MAX;
    float c = (float)rand() / (float)RAND_MAX;

    //convert to string
    //-copilot next line-
//copilot mean_prob: 0.6044212993474802

    char *myFloat1 = malloc(sizeof(char) * 30);
    char *myFloat2 = malloc(sizeof(char) * 30);
    char *myFloat3 = malloc(sizeof(char) * 30);
    char *myFloat4 = malloc(sizeof(char) * 30);






}